from flask import Flask, render_template, request, redirect, url_for
import pymysql
import boto3
import json
from werkzeug.utils import secure_filename
from werkzeug.datastructures import  FileStorage
import os

ACCESS_KEY = "AKIAXRKLK6M4OZZMLOPC"
SECRET_KEY ="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"

ENDPOINT="project.cllojotlzdma.us-east-2.rds.amazonaws.com"
PORT="3306"
USR="admin"
PASSWORD="password"
DBNAME="UserDetails"


app = Flask(__name__)

@app.route('/')
def main():
    return redirect("initialize")

@app.route('/login')
def login():    
    return render_template("login.html")

@app.route('/notfound')
def notfound():
    return render_template("usernotfound.html")

@app.route('/register')
def register():
    return render_template("register.html")  

@app.route('/repeat')
def repeat():
    return render_template("mainpage.html") 

@app.route('/add', methods=["POST"])
def add():
    email = request.form.get("email")
    password= request.form.get("password")
    conn =  pymysql.connect(host=ENDPOINT, user=USR, password=PASSWORD, database=DBNAME)
    cur = conn.cursor()
    cur.execute("INSERT INTO userdetails(email,password) VALUES('"+email+"','"+password+"');")
    print("Insert Success")
    conn.commit()

    return redirect("/login")
 
@app.route('/upload',methods=["POST"])
def upload():
    amount1 = request.form.get("amount1")
    amount2 = request.form.get("amount2")
    amount3 = request.form.get("amount3")
    amount4 = request.form.get("amount4")
    global recemail
    recipient = request.form.get("recemail")
    Totalamount = int(amount1) + int(amount2) + int(amount3) + int(amount4)
    print(emailglobal,amount1,amount2,amount3,amount4,Totalamount)
    print("fetch success")

    conn =  pymysql.connect(host=ENDPOINT, user=USR, password=PASSWORD, database=DBNAME)
    cur = conn.cursor()
    cur.execute("UPDATE userdetails SET Totalamount='"+str(Totalamount)+"', amount1='"+amount1+"',amount2='"+amount2+"',amount3='"+amount3+"',amount4='"+amount4+"', recipient='"+recipient+"' where email = '"+emailglobal+"';")
    print("Update Success")
    conn.commit()

    return render_template("Uploadsuccess.html")
            
@app.route('/mainpage',methods=["GET"])
def mainpage():
    email=request.args.get('email')
    global emailglobal
    emailglobal=email
    password= request.args.get('password')
    print(email,password)
    try:
            conn =  pymysql.connect(host=ENDPOINT, user=USR, password=PASSWORD, database=DBNAME)
            cur = conn.cursor()
            qry= "SELECT * FROM userdetails Where email ='"+email+"' AND password = '"+password+"';"
            print(qry)
            cur.execute("SELECT * FROM userdetails;")
            query_results = cur.fetchall()
            print(query_results)
            cur.execute("SELECT * FROM userdetails Where email ='"+email+"' AND password = '"+password+"';")
            query_results = cur.fetchall()
            print(query_results)
            if len(query_results)==1:
               return render_template("mainpage.html")
            else:
                return redirect("/notfound")
    except Exception as e:
            print("Database connection failed due to {}".format(e))
            return redirect("/login")

@app.route('/initialize')
def initialize():
    try:
        print("INITIALIZING DATABASE")
        conn =  pymysql.connect(host=ENDPOINT, user=USR, password=PASSWORD, database=DBNAME)
        cur = conn.cursor()
        try:
            cur.execute("DROP TABLE userdetails;")
            print("table deleted")
        except Exception as e:
            print("cannot delete table")
        cur.execute("CREATE TABLE userdetails(email VARCHAR(30), password VARCHAR(30), Totalamount INTEGER, amount1 INTEGER, amount2 INTEGER, amount3 INTEGER, amount4 INTEGER, recipient VARCHAR(30));")
        print("table created")
        cur.execute("INSERT INTO userdetails(email,password) VALUES('test1@gmail.com','pass');")
        print("Insert Success")
        conn.commit()
        return redirect("/login")
    except Exception as e:
        print("Database connection failed due to {}".format(e))
        return redirect("/login")


if __name__=="__main__":
    app.run(host='0.0.0.0',debug=True)
